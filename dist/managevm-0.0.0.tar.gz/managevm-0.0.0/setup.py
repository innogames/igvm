#!/usr/bin/env python
from distutils.core import setup

setup(
        name='managevm',
        py_modules=['managevm'],
        author='Henning Pridohl',
        author_email='henning.pridohl@innogames.de',
        maintainer='Kajetan Staszkiewicz',
        maintainer_email='kajetan.staszkiewicz@innogames.de',
        )

